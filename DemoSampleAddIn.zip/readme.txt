In order to use the add-in:
- deploy the files on IIS (or any other web server of choice)
- put the manifest file in a locally shared directory
- add the shared directory to Excel's Trust Center
- manifest is set to lookup the files from localhost on port 1375