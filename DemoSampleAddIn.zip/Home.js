var iter = 0;

(function () {
    "use strict";

    Office.initialize = function (reason) {
        $(document).ready(function () {
            app.initialize();

            $('#load-data-segments').click(load);
        });
    };
    var t1, t0, partTime0, partTime1;

    function load() {
        document.getElementById("load-data-segments").disabled = true;
        loadDataSegments(iter++);
    }
    
    function loadDataSegments(i) {
        t0 = performance.now();

        Excel.run(function (ctx) {
            var sheet = ctx.workbook.worksheets.getActiveWorksheet();

            partTime0 = performance.now();

            var rangeString = "A" + (1000 * i + 1).toString() + ":FD" + ((i + 1) * 1000).toString();
            console.log(rangeString);

            var range = sheet.getRange(rangeString);
            range.values = values;

            partTime1 = performance.now();
            console.log((i+1) + ". " + (partTime1 - partTime0) + "ms");
            
            return ctx.sync();
        })
        .then(function () {
            document.getElementById("load-data-segments").disabled = false;
            t1 = performance.now();
            console.log((i+1) + ". " + (t1 - t0) + "ms");
            app.showNotification("Success " + (t1 - t0) + "ms");
            console.log("Success!");
        })
        .catch(function (error) {
            document.getElementById("load-data-segments").disabled = false;
            app.showNotification("Error: " + error);
            console.log("Error: " + error);
            if (error instanceof OfficeExtension.Error) {
                console.log("Debug info: " + JSON.stringify(error.debugInfo));
            }
        });
    }
})();